package com.oppo.chromaos.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

class ChromaBubble @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pulse = 0.5f
    private var primary = 0xFF00F5A0.toInt()
    private var animator: ValueAnimator? = null

    init { isClickable = true }

    fun setAuraColor(color: Int) { primary = color; invalidate() }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0.82f, 1.08f).apply {
            duration = 1300
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { pulse = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(width, height) * 0.36f * pulse
        paint.shader = RadialGradient(cx, cy, r * 1.7f,
            intArrayOf((primary and 0x00FFFFFF) or 0x99000000, (primary and 0x00FFFFFF) or 0xFF000000, 0xFF121522),
            null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 1.35f, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = 0xCCFFFFFF.toInt()
        canvas.drawCircle(cx, cy, r, paint)
        paint.style = Paint.Style.FILL
        paint.color = 0xFFFFFFFF.toInt()
        canvas.drawCircle(cx, cy, r * 0.10f, paint)
    }
}
