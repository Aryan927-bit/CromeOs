package com.oppo.chromaos.engine

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Microphone-input visualizer. Android does not let ordinary apps capture
 * other apps' internal audio through AudioRecord; this listens to the mic.
 */
class AudioVisualizer(
    private val sampleRate: Int = 44100,
    private val fftSize: Int = 1024
) {
    companion object {
        const val BAND_COUNT = 16
    }

    private val buffer = ShortArray(fftSize)
    private val re = DoubleArray(fftSize)
    private val im = DoubleArray(fftSize)
    private val magnitudes = DoubleArray(fftSize / 2)
    private val smoothedBands = DoubleArray(BAND_COUNT)
    private val window = DoubleArray(fftSize) {
        0.5 * (1 - cos(2 * PI * it / (fftSize - 1)))
    }

    @Volatile private var isRunning = false
    private var audioThread: Thread? = null
    private var audioRecord: AudioRecord? = null

    fun start() {
        if (isRunning) return
        isRunning = true
        audioThread = Thread {
            try {
                val minBufferSize = AudioRecord.getMinBufferSize(
                    sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBufferSize <= 0) return@Thread
                val record = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBufferSize, fftSize * 2)
                )
                audioRecord = record
                if (record.state != AudioRecord.STATE_INITIALIZED) {
                    record.release()
                    audioRecord = null
                    return@Thread
                }
                record.startRecording()
                while (isRunning) {
                    val read = record.read(buffer, 0, buffer.size)
                    if (read > 0) processBuffer(buffer, read)
                }
            } catch (_: SecurityException) {
                // RECORD_AUDIO permission was not granted.
            } catch (_: Exception) {
                // Device-specific audio capture errors should not crash the app.
            } finally {
                try {
                    audioRecord?.let {
                        if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) it.stop()
                        it.release()
                    }
                } catch (_: Exception) { }
                audioRecord = null
            }
        }.apply { name = "ChromaOS-AudioVisualizer"; isDaemon = true }
        audioThread?.start()
    }

    fun stop() {
        isRunning = false
        try { audioRecord?.stop() } catch (_: Exception) { }
        try { audioThread?.join(500) } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
        audioThread = null
    }

    fun getBand(index: Int): Float = if (index in smoothedBands.indices) smoothedBands[index].toFloat() else 0f
    fun getBassEnergy(): Float = smoothedBands.take(4).average().toFloat()
    fun getOverallEnergy(): Float = smoothedBands.average().toFloat()

    @Synchronized
    private fun processBuffer(samples: ShortArray, size: Int) {
        for (i in 0 until fftSize) {
            re[i] = if (i < size) (samples[i] / 32768.0) * window[i] else 0.0
            im[i] = 0.0
        }
        performFFT()
        for (i in magnitudes.indices) magnitudes[i] = sqrt(re[i].pow(2) + im[i].pow(2))
        updateBands()
    }

    private fun updateBands() {
        val maxBin = fftSize / 2 - 1
        val logMax = kotlin.math.ln(maxBin.toDouble())
        for (b in 0 until BAND_COUNT) {
            val start = kotlin.math.exp(logMax * b / BAND_COUNT).toInt().coerceIn(1, maxBin)
            val end = kotlin.math.exp(logMax * (b + 1) / BAND_COUNT).toInt().coerceIn(start + 1, maxBin + 1)
            var sum = 0.0
            var count = 0
            for (i in start until end) { sum += magnitudes[i]; count++ }
            val target = ((if (count > 0) sum / count else 0.0) * 10.0).coerceIn(0.0, 1.0)
            smoothedBands[b] = smoothedBands[b] * 0.7 + target * 0.3
        }
    }

    private fun performFFT() {
        val n = fftSize
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val angle = -2.0 * PI / len
            val wLenRe = cos(angle)
            val wLenIm = sin(angle)
            var start = 0
            while (start < n) {
                var wr = 1.0
                var wi = 0.0
                for (k in 0 until len / 2) {
                    val u = start + k
                    val v = u + len / 2
                    val vr = re[v] * wr - im[v] * wi
                    val vi = re[v] * wi + im[v] * wr
                    re[u] += vr; im[u] += vi
                    re[v] -= vr; im[v] -= vi
                    val nextWr = wr * wLenRe - wi * wLenIm
                    wi = wr * wLenIm + wi * wLenRe
                    wr = nextWr
                }
                start += len
            }
            len *= 2
        }
    }
}
