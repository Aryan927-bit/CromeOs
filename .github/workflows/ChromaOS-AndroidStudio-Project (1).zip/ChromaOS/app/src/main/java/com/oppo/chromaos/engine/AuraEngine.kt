package com.oppo.chromaos.engine

import android.graphics.Color
import kotlin.math.sin

class AuraEngine {
    private var primaryColor = Color.rgb(0, 245, 160)
    private var darkColor = Color.rgb(4, 18, 24)
    private var bassEnergy = 0f
    private var overallEnergy = 0f

    fun updateColors(primary: Int, dark: Int) {
        primaryColor = primary
        darkColor = dark
    }

    fun updateAudio(bass: Float, overall: Float) {
        bassEnergy = bass.coerceIn(0f, 1f)
        overallEnergy = overall.coerceIn(0f, 1f)
    }

    fun primaryColor() = primaryColor
    fun darkColor() = darkColor
    fun bassEnergy() = bassEnergy
    fun overallEnergy() = overallEnergy
    fun intensity(phase: Float): Float =
        (0.25f + 0.25f * (0.5 + 0.5 * sin(phase * 2.0 * Math.PI)).toFloat() + bassEnergy * 0.5f)
            .coerceIn(0f, 1f)
}
