package com.oppo.chromaos.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator

class VinylView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var rotation = 0f
    private var playing = true
    private var accent = 0xFF00F5A0.toInt()
    private var albumArt: Bitmap? = null
    private var animator: ValueAnimator? = null

    fun setPlaying(value: Boolean) {
        playing = value
        if (playing) startSpin() else { animator?.cancel(); animator = null }
    }
    fun setAccentColor(color: Int) { accent = color; invalidate() }
    fun setAlbumArt(bitmap: Bitmap?) { albumArt = bitmap; invalidate() }

    private fun startSpin() {
        if (animator != null || !playing) return
        animator = ValueAnimator.ofFloat(rotation, rotation + 360f).apply {
            duration = 6000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { rotation = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (playing) startSpin() }
    override fun onDetachedFromWindow() { animator?.cancel(); animator = null; super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = minOf(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val radius = size * 0.46f
        canvas.save()
        canvas.rotate(rotation, cx, cy)
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(18, 20, 28)
        canvas.drawCircle(cx, cy, radius, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = size * 0.008f
        for (i in 1..9) {
            paint.color = if (i % 3 == 0) 0xFF454957.toInt() else 0xFF292D39.toInt()
            canvas.drawCircle(cx, cy, radius * (i / 10f), paint)
        }
        paint.style = Paint.Style.FILL
        paint.color = 0xFF090B12.toInt()
        canvas.drawCircle(cx, cy, radius * 0.38f, paint)
        canvas.restore()

        val centerR = radius * 0.34f
        val art = albumArt
        if (art != null && !art.isRecycled) {
            val shader = BitmapShader(art, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            paint.shader = shader
            canvas.drawCircle(cx, cy, centerR, paint)
            paint.shader = null
        } else {
            paint.color = accent
            canvas.drawCircle(cx, cy, centerR, paint)
            paint.color = 0xFF10131B.toInt()
            canvas.drawCircle(cx, cy, centerR * 0.24f, paint)
        }
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = size * 0.012f
        paint.color = 0xCCFFFFFF.toInt()
        canvas.drawCircle(cx, cy, centerR, paint)
        paint.style = Paint.Style.FILL
    }
}
