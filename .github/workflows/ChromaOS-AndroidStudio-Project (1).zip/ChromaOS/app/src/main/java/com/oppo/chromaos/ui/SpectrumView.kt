package com.oppo.chromaos.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class SpectrumView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bands = FloatArray(16)
    private var accent = 0xFF00F5A0.toInt()

    fun setAccentColor(color: Int) { accent = color; invalidate() }
    fun setBands(values: FloatArray) {
        for (i in bands.indices) bands[i] = (values.getOrNull(i) ?: 0f).coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val gap = width * 0.012f
        val barWidth = (width - gap * (bands.size - 1)) / bands.size
        val baseY = height.toFloat()
        for (i in bands.indices) {
            val display = maxOf(bands[i], 0.08f + 0.04f * kotlin.math.abs(kotlin.math.sin((System.nanoTime() / 1e9 + i) * 2.0)).toFloat())
            val barHeight = maxOf(height * 0.12f, height * display * 0.92f)
            paint.color = accent
            paint.alpha = (150 + 105 * display).toInt().coerceIn(0, 255)
            val left = i * (barWidth + gap)
            canvas.drawRoundRect(RectF(left, baseY - barHeight, left + barWidth, baseY), barWidth / 2, barWidth / 2, paint)
        }
        paint.alpha = 255
        postInvalidateDelayed(45)
    }
}
