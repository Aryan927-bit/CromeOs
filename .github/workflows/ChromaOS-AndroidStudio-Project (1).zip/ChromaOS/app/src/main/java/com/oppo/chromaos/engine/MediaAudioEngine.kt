package com.oppo.chromaos.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.oppo.chromaos.MainActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class MediaAudioEngine : Service() {
    companion object {
        const val CHANNEL_ID = "chroma_channel"
        const val NOTIFICATION_ID = 1001
    }

    inner class LocalBinder : android.os.Binder() {
        fun service(): MediaAudioEngine = this@MediaAudioEngine
    }

    private val binder = LocalBinder()
    private lateinit var sessionManager: MediaSessionManager
    private var activeController: MediaController? = null
    private var sessionListener: MediaSessionManager.OnActiveSessionsChangedListener? = null
    private val handler = Handler(Looper.getMainLooper())

    data class ChromaState(
        val title: String = "No music detected",
        val artist: String = "Play music in your preferred player",
        val albumArt: Bitmap? = null,
        val isPlaying: Boolean = false,
        val primaryColor: Int = Color.rgb(0, 245, 160),
        val darkColor: Int = Color.rgb(4, 18, 24)
    )

    private val _uiState = MutableStateFlow(ChromaState())
    val uiState: StateFlow<ChromaState> = _uiState
    private var currentArt: Bitmap? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        sessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { sessions ->
            attachToBestSession(sessions)
        }
        registerSessionListener()
        attachToBestSession(sessionManager.getActiveSessions(
            ComponentName(this, ChromaNotificationListener::class.java)
        ))
    }

    private fun registerSessionListener() {
        try {
            sessionManager.addOnActiveSessionsChangedListener(
                sessionListener!!,
                ComponentName(this, ChromaNotificationListener::class.java),
                handler
            )
        } catch (_: SecurityException) {
            // User needs to enable Notification Access from Android Settings.
        }
    }

    private fun attachToBestSession(sessions: List<MediaController>?) {
        val controller = sessions?.lastOrNull()
        if (controller == null) {
            activeController?.unregisterCallback(controllerCallback)
            activeController = null
            _uiState.value = ChromaState()
            return
        }
        try {
            activeController?.unregisterCallback(controllerCallback)
            activeController = controller.also {
                it.registerCallback(controllerCallback, handler)
                updateFromController(it)
            }
        } catch (_: Exception) { }
    }

    private val controllerCallback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            updateFromController(activeController, metadata)
        }
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            _uiState.value = _uiState.value.copy(
                isPlaying = state?.state == PlaybackState.STATE_PLAYING
            )
        }
        override fun onSessionDestroyed() {
            activeController?.unregisterCallback(this)
            activeController = null
            _uiState.value = ChromaState()
        }
    }

    private fun updateFromController(controller: MediaController?, metadata: MediaMetadata? = null) {
        val meta = metadata ?: controller?.metadata
        if (meta == null) return
        val desc = meta.description
        val art = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: desc.iconBitmap
        if (art != null) {
            currentArt = try { Bitmap.createScaledBitmap(art, 256, 256, true) } catch (_: Exception) { art }
        }
        val (primary, dark) = extractPalette(currentArt)
        _uiState.value = ChromaState(
            title = desc.title?.toString()?.takeIf { it.isNotBlank() } ?: "Unknown title",
            artist = desc.subtitle?.toString()?.takeIf { it.isNotBlank() }
                ?: desc.description?.toString()?.takeIf { it.isNotBlank() } ?: "Unknown artist",
            albumArt = currentArt,
            isPlaying = controller?.playbackState?.state == PlaybackState.STATE_PLAYING,
            primaryColor = primary,
            darkColor = dark
        )
    }

    private fun extractPalette(bitmap: Bitmap?): Pair<Int, Int> {
        if (bitmap == null) return Color.rgb(0, 245, 160) to Color.rgb(4, 18, 24)
        val small = Bitmap.createScaledBitmap(bitmap, 32, 32, true)
        var r = 0L; var g = 0L; var b = 0L; var n = 0L
        for (y in 0 until small.height) for (x in 0 until small.width) {
            val pixel = small.getPixel(x, y)
            if (Color.alpha(pixel) < 128) continue
            val brightness = (Color.red(pixel) + Color.green(pixel) + Color.blue(pixel)) / 3
            if (brightness !in 12..242) continue
            r += Color.red(pixel); g += Color.green(pixel); b += Color.blue(pixel); n++
        }
        if (n == 0L) return Color.rgb(0, 245, 160) to Color.rgb(4, 18, 24)
        val primary = Color.rgb((r / n).toInt(), (g / n).toInt(), (b / n).toInt())
        val dark = Color.rgb((Color.red(primary) * .22).toInt(), (Color.green(primary) * .22).toInt(), (Color.blue(primary) * .22).toInt())
        return primary to dark
    }

    fun playPause() {
        val controller = activeController ?: return
        try {
            if (controller.playbackState?.state == PlaybackState.STATE_PLAYING) controller.transportControls.pause()
            else controller.transportControls.play()
        } catch (_: Exception) { }
    }
    fun next() { try { activeController?.transportControls?.skipToNext() } catch (_: Exception) { } }
    fun prev() { try { activeController?.transportControls?.skipToPrevious() } catch (_: Exception) { } }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "ChromaOS status", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    private fun createNotification(): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ChromaOS Music Aura")
            .setContentText("Ready to connect to your music")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        sessionListener?.let {
            try { sessionManager.removeOnActiveSessionsChangedListener(it) } catch (_: Exception) { }
        }
        activeController?.unregisterCallback(controllerCallback)
        super.onDestroy()
    }
}
