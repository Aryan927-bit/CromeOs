package com.oppo.chromaos.engine

import android.service.notification.NotificationListenerService

/**
 * Declaring this listener allows Android to expose active media sessions
 * after the user explicitly enables ChromaOS in Notification Access settings.
 */
class ChromaNotificationListener : NotificationListenerService()
