package com.oppo.chromaos

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.media.session.MediaSessionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.oppo.chromaos.engine.AudioVisualizer
import com.oppo.chromaos.engine.ChromaNotificationListener
import com.oppo.chromaos.engine.MediaAudioEngine
import com.oppo.chromaos.ui.AuraBackground
import com.oppo.chromaos.ui.ChromaBubble
import com.oppo.chromaos.ui.SpectrumView
import com.oppo.chromaos.ui.VinylView
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private var engine: MediaAudioEngine? = null
    private var bound = false
    private var visualizer: AudioVisualizer? = null
    private lateinit var aura: AuraBackground
    private lateinit var bubble: ChromaBubble
    private lateinit var vinyl: VinylView
    private lateinit var spectrum: SpectrumView
    private lateinit var title: TextView
    private lateinit var artist: TextView
    private lateinit var status: TextView
    private lateinit var accessButton: Button
    private lateinit var playPause: ImageButton

    private val audioPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startVisualizer()
        else status.text = "Microphone permission is needed for mic-based visualization"
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            engine = (service as? MediaAudioEngine.LocalBinder)?.service()
            bound = engine != null
            observeEngine()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            engine = null
            bound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        aura = findViewById(R.id.auraBackground)
        bubble = findViewById(R.id.chromaBubble)
        vinyl = findViewById(R.id.vinylView)
        spectrum = findViewById(R.id.spectrumView)
        title = findViewById(R.id.tvTitle)
        artist = findViewById(R.id.tvArtist)
        status = findViewById(R.id.tvStatus)
        accessButton = findViewById(R.id.btnMediaAccess)
        playPause = findViewById(R.id.btnPlayPause)

        findViewById<ImageButton>(R.id.btnPrev).setOnClickListener { engine?.prev() }
        findViewById<ImageButton>(R.id.btnNext).setOnClickListener { engine?.next() }
        playPause.setOnClickListener { engine?.playPause() }
        bubble.setOnClickListener { toggleMediaAccess() }
        accessButton.setOnClickListener { toggleMediaAccess() }

        val serviceIntent = Intent(this, MediaAudioEngine::class.java)
        ContextCompat.startForegroundService(this, serviceIntent)
        bindService(serviceIntent, connection, Context.BIND_AUTO_CREATE)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            startVisualizer()
        } else {
            audioPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 202)
        }
    }

    private fun observeEngine() {
        val service = engine ?: return
        lifecycleScope.launch {
            service.uiState.collect { state ->
                title.text = state.title
                artist.text = state.artist
                vinyl.setAlbumArt(state.albumArt)
                vinyl.setPlaying(state.isPlaying)
                vinyl.setAccentColor(state.primaryColor)
                bubble.setAuraColor(state.primaryColor)
                spectrum.setAccentColor(state.primaryColor)
                aura.setAuraColors(state.primaryColor, state.darkColor)
                playPause.setImageResource(if (state.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
                status.text = if (hasNotificationAccess()) {
                    if (state.isPlaying) "Now playing · media session connected" else "Media access enabled"
                } else "Enable media access to read your music session"
            }
        }
        lifecycleScope.launch {
            while (true) {
                val v = visualizer
                if (v != null) {
                    val values = FloatArray(AudioVisualizer.BAND_COUNT) { v.getBand(it) }
                    spectrum.setBands(values)
                    aura.setAudioEnergy(v.getBassEnergy(), v.getOverallEnergy())
                }
                delay(70)
            }
        }
    }

    private fun startVisualizer() {
        if (visualizer != null) return
        visualizer = AudioVisualizer().also { it.start() }
    }

    private fun toggleMediaAccess() {
        if (!hasNotificationAccess()) {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        } else {
            status.text = "Media access is enabled. Start playing music in another app."
        }
    }

    private fun hasNotificationAccess(): Boolean {
        val component = ComponentName(this, ChromaNotificationListener::class.java)
        val flat = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return flat.split(":").any { it.equals(component.flattenToString(), ignoreCase = true) }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && !hasNotificationAccess()) {
            status.text = "Tap Enable media access, then allow ChromaOS in Settings"
        }
    }

    override fun onDestroy() {
        visualizer?.stop()
        visualizer = null
        if (bound) unbindService(connection)
        super.onDestroy()
    }
}
