package com.oppo.chromaos.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import com.oppo.chromaos.engine.AuraEngine
import kotlin.math.sin

class AuraBackground @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val engine = AuraEngine()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var primary = 0xFF00F5A0.toInt()
    private var dark = 0xFF041218.toInt()
    private var audioEnergy = 0f
    private var animator: ValueAnimator? = null

    init { setLayerType(LAYER_TYPE_SOFTWARE, null) }

    fun setAuraColors(primaryColor: Int, darkColor: Int) {
        primary = primaryColor
        dark = darkColor
        engine.updateColors(primaryColor, darkColor)
        invalidate()
    }

    fun setAudioEnergy(bass: Float, overall: Float) {
        audioEnergy = bass.coerceIn(0f, 1f)
        engine.updateAudio(bass, overall)
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        animator = ValueAnimator.ofFloat(0f, (Math.PI * 2).toFloat()).apply {
            duration = 7000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(dark)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0 || h <= 0) return
        val pulse = (0.5f + 0.5f * sin(phase.toDouble())).toFloat()
        val radius = (w.coerceAtLeast(h) * (0.38f + pulse * 0.13f + audioEnergy * 0.12f))
        val x1 = w * (0.28f + 0.10f * sin(phase.toDouble()).toFloat())
        val y1 = h * 0.36f
        paint.shader = RadialGradient(
            x1, y1, radius,
            intArrayOf(withAlpha(primary, (50 + pulse * 55 + audioEnergy * 80).toInt()), withAlpha(primary, 22), 0x00000000),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = RadialGradient(
            w * 0.78f, h * 0.72f, radius * 0.8f,
            intArrayOf(withAlpha(0xFF8A5CFF.toInt(), (25 + pulse * 35).toInt()), 0x008A5CFF, 0x00000000),
            null, Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}
