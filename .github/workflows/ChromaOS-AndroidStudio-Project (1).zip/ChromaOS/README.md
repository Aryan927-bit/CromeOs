# ChromaOS: Music Aura

Android Studio project source for ChromaOS, with a GitHub Actions workflow to build the APK in the cloud.

## Build the APK using GitHub (phone-friendly)
1. Download and extract `ChromaOS-AndroidStudio-Project.zip`.
2. In a browser, sign in to GitHub and create a **new public or private repository** named `ChromaOS`.
3. Upload the *contents* of the extracted `ChromaOS` folder to the repository root (make sure `.github/workflows/android.yml` is included). Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and select **Build ChromaOS APK**. If asked, enable GitHub Actions, then tap **Run workflow**.
5. Wait for the run to finish with a green check mark. Open that run, scroll to **Artifacts**, and download **ChromaOS-debug-APK**.
6. Extract the downloaded artifact ZIP. It contains `app-debug.apk`. Open it on your Android phone and follow Android's install prompt. If prompted, allow your browser/file manager to install unknown apps.

The workflow also starts automatically whenever you push a commit to `main`.

## Build locally in Android Studio
1. Open this project folder in Android Studio.
2. Install Android SDK Platform 35 and Android SDK Build-Tools when prompted.
3. Sync Gradle, then choose Build > Build APK(s).
4. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## First launch
- Grant microphone permission if you want the microphone-based spectrum animation.
- Tap **Enable media access** and enable ChromaOS under Notification Access to read media-session metadata and send playback commands.
- Start music in another player.

## Important limitation
`AudioRecord` visualizes microphone input, not another app's private internal audio stream. Android restricts internal audio capture; this project does not silently capture other apps' audio. Media metadata and playback controls are separate and use the user's notification access grant.

## Build status
This project has not yet been compiled in this environment. The GitHub Actions workflow is configured to compile it and publish the debug APK as an artifact. If the build fails, open the failed workflow run and share the error log so the issue can be fixed.
